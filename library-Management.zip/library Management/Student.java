public class Student extends Protector
{
    String studentId;
    String guardianName;
    String guardianContactNo;
    String guardianRelation;
	
	
	
	public Student()
	{
		System.out.println("  " );
	}
	
	public Student(String studentId, String guardianName, String guardianContactNo, String guardianRelation)
	{
		this.studentId=studentId;
		this.guardianName=guardianName;
		this.guardianContactNo=guardianContactNo;
		this.guardianRelation=guardianRelation;
	}
	
	
	
	
    public void setStudentId(String studentId)
	{
        this.studentId=studentId;
    }
	
    public void setGuardianName(String guardianName)
	{
        this.guardianName=guardianName;
    }
    public void setGuardianContactNo(String guardianContactNo)
	{
        this.guardianContactNo=guardianContactNo;
    }
	public void setGuardianRelation(String guardianRelation)
	{
		this.guardianRelation=guardianRelation;
	}
	
    public String getStudentId()
	{
        return studentId;
    }
  
    public String getGuardianName()
	{
        return guardianName;
    }
    public String getGuardianContactNo()
	{
        return guardianContactNo;
    }
	public String getGuardianRelation()
	{
		return guardianRelation;
	}
	
    public void showInfo()
	{
        System.out.println("Library ID: "+id);
        System.out.println("Student ID: "+studentId);
        System.out.println("Name: "+name);
        System.out.println("Department Name: "+departmentName);
        System.out.println("Email: "+email);
        System.out.println("Contact No: "+contactNo);
        System.out.println("Address: "+address);
        System.out.println("Local Gurdian Name: "+guardianName);
        System.out.println("Gurdian Contact No: "+guardianContactNo);
        System.out.println("Gurdian Relation : "+guardianRelation);

    }
    
}