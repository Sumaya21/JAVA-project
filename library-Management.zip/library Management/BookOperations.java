import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class BookOperations
{
    File file = new File("Documents/Books_Documents.txt");
    FileWriter fileWriter = null;
    FileReader fileReader = null;
    String line;
    int count;
    char choice;
	String bookReciveDate;
    Author author;
    String id;
    boolean bookStatus = true;
    Scanner in = new Scanner(System.in);
    boolean doesContain;
	

    public void insertBook(Book b)
	{

        System.out.println("\n\tEnter Book ID: ");
        int bId=in.nextInt();
        b.setId(bId);
        in.nextLine();

        System.out.println("\n\tEnter Book Title ");
        String title = in.nextLine();
        b.setTitle(title);
		
		
		
		
		System.out.println("\n\tEnter Book Receive  Date: ");
        String bookrecivedate = in.nextLine();
        b.setBookreciveDate(bookrecivedate);

        

        System.out.println("\n\tAuthor details");
        author=new Author();
        b.setAuthor(author);
		

        
		
		

        
            try 
			{
            
                fileWriter = new FileWriter(file, true);
                 fileWriter.write("\nBook ID: " + b.getId() + "\nTitle: "+ b.getTitle() + "\nBook Book Recive Date:"+b.getBookreciveDate()+
                 "\nAuthor ID: "+ author.getId() +"\nAuthor Name: "+ author.getName() + "\nAuthor Email: " + author.getEmail()   );
				 
				 
                
				 System.out.println("\n\t\t\tThank you!!");
            }
            catch(IOException io)
			{
                System.out.println("............!!  Error Exception !!...............");
            }
            finally 
			{
                try 
				{
                    fileWriter.close();
                }
                catch(IOException io)
				{
                    System.out.println("!!!!!!!!!!!!!!!!!!Can not close the resource!!!!!!!!!!!!!!!!!");
                }
            }
        
       
    }

    public Book getBook(int bookId)
	{
        Book bk = new Book();
        id = Integer.toString(bookId);
        int numberOfLinePrint = 10;
        try
		{
            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            line = null;
            doesContain = false;
            count = 0;
            while((line = bufferedReader.readLine())!= null)
			{
                if(line.contains(id))
				{
                    doesContain = true;
                    System.out.println(line);
                    count++;
                    continue;
                }
                else if(doesContain && count < numberOfLinePrint)
				{
                    count++;
                    System.out.println(line);
                }
                else if(doesContain && count == numberOfLinePrint)
				{
                    System.out.println(line);
                    doesContain = false;
                }
            }
        }

        catch(IOException io) 
		{
            System.out.println("..........!!  Error Exception !!.............");
        }

        finally
		{
            try
			
			{
                fileReader.close();

            }
            catch(IOException io)
			{
                System.out.println("!!!!!!Can not close the resource!!!!!!!");
            }

        }
        return bk ;
    }

    public void showAllBooks()
	{
        try
		{
            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while((line = bufferedReader.readLine())!= null)
			{
                System.out.println(line);
            }
        }
        catch(IOException io)
		{
            System.out.println("............!! Error Exception !!.............");
        }

        finally
		{
            try
			{
                fileReader.close();
            }
            catch(IOException io)
			{
                System.out.println("!!!!!!!!Can not close the resource!!!!!!!!!!!!!!!!!!!!!!!");
            }
        }
    }
}