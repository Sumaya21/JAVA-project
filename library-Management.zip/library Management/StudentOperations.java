import java.util.Scanner;
import java.io.*;

public class StudentOperations 
{
    File file = new File("Documents/Students_Documents.txt");
    FileWriter fileWriter = null;
    FileReader fileReader=null;
    String line;
    boolean isContaintFound;
    int count;
    Scanner in=new Scanner(System.in);
    String id;
    char choice;

    public void insertStudent(Student S)
	{
        System.out.println("Enter  Student libary ID: ");
        int lid=in.nextInt();
        S.setId(lid);
        in.nextLine();
	    
        System.out.println("  Student Vercity  ID: ");
        String sid=in.nextLine();
        S.setStudentId(sid);
	    
        System.out.println("Enter  Student Name: ");
        String sname=in.nextLine();
        S.setName(sname);
	    
        System.out.println("Enter  Student Depertment Name: ");
        String sdepartmentName=in.nextLine();
        S.setDepartmentName(sdepartmentName);
	    
        System.out.println("Enter  Student Email: ");
        String semail=in.nextLine();
        S.setEmail(semail);
	    
        System.out.println("Enter  Student ContactNo: ");
        String scontactNo=in.nextLine();
        S.setContactNo(scontactNo);
	
        System.out.println("Enter  Student Address: ");
        String saddress=in.nextLine();
        S.setAddress(saddress);
	
        System.out.println("Enter  Local  Guardian Name: ");
        String sguardianName=in.nextLine();
        S.setGuardianName(sguardianName);
		
		
		
		System.out.println("Enter  Guardian relation: ");
        String sguardianRelation=in.nextLine();
        S.setGuardianRelation(sguardianRelation);

	
        System.out.println("Enter   Guardian Contact No: ");
        String sguardianContactNo=in.nextLine();
        S.setGuardianContactNo(sguardianContactNo);
		
		

         try 
		 {
            
            fileWriter = new FileWriter(file, true);
            fileWriter.write("\nLibrary ID: "+S.getId()+"\nStudent ID: " + S.getStudentId() + "\nName: "+ S.getName() +"\nDepartment Name: "+ S.getDepartmentName() +
            "\nEmail: "+ S.getEmail()+"\nContact No: "+ S.getContactNo()+ "\nAddress: " + S.getAddress()+
             "\nGurdian Name: "+ S.getGuardianName()+ "\nGurdian Contact No: "+ S.getGuardianContactNo()+ "\nGurdian realtion: "+ S.getGuardianRelation());
            
			System.out.println("\n\t\t\tHave A nice Day My Dear!!");
            }
            catch(IOException io) 
			{
                System.out.println(" Error Exception !!");
            }
            finally 
			{
                try 
				{
                    fileWriter.close();
                }
                catch(IOException io) 
				{
                    System.out.println("Can not close the resource!!");
                }
            }
        
        
    }
        

   

    public Student getStudent(int studentID)
	{
        Student student=new Student();
        id = Integer.toString(studentID);
        int numberOfLinePrint=10;
        try
		{

            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            line=null;
            isContaintFound=false;
            count = 0;
            while ((line = bufferedReader.readLine()) != null)
			{
                if (line.contains("Student ID: "+id))
				{
                    isContaintFound = true;
                    System.out.println(line);
                    count++;
                    continue;
                }
                else if(isContaintFound && count < numberOfLinePrint)
				{
                    count++;
                    System.out.println(line);
                }
                else if (isContaintFound && count == numberOfLinePrint)
				{
                    System.out.println(line);
                    isContaintFound = false;
                }
            }
        }
        catch(IOException io) 
		{
            System.out.println(" Error Exception !!");
        }
        finally 
		{
            try 
			{
                fileReader.close();
            }
            catch(IOException io) 
			{
                System.out.println("Can not close the resource!!");
            }
        }
       
        return student;
    }





    public void showAllStudents()
	{
        try
		{

            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while ((line = bufferedReader.readLine()) != null)
			{
                System.out.println(line);
            }
        }
        catch(IOException io)
		{
            System.out.println(" Error Exception !!");
        }
        finally 
		{
            try 
			{
                fileReader.close();
            }
            catch(IOException io) 
			{
                System.out.println("Can not close the resource!!");
            }
        } 
    } 
}
