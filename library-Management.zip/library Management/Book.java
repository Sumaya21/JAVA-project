import java.util.Scanner;

public class Book
{
    int id;
    String title;
	String bookrecivedate;
    Author author;
    
    public Book()
	{
		System.out.println("  " );
	}
	
	public Book(int id, String title, String bookrecivedate)
	{
		this.id=id;
		this.title=title;
		this.bookrecivedate=bookrecivedate;
	}
	
		
	
	
    Scanner in = new Scanner(System.in);

    public void setId(int id)
	{
        this.id=id;
    }
    public void setTitle(String title)
	{
        this.title=title;
    }
	public void setBookreciveDate(String bookrecivedate)
	{
		this.bookrecivedate=bookrecivedate;
	}
	
	public int getId()
	{
        return id;
    }
	public String getTitle()
	{
		return title;
	}	
	public String getBookreciveDate()
	{
        return bookrecivedate;
    }
	
	

  
    public void setAuthor(Author author)
	{
        this.author=author;
        System.out.println("Enter Author ID: ");
        int authorId = in.nextInt();
        in.nextLine();
        author.setId(authorId);

        System.out.println("Enter Author Name: ");
        String name = in.nextLine();
        author.setName(name);

        System.out.println("Enter Author Email: ");
        String email = in.nextLine();
        author.setEmail(email);
		
		System.out.println("Enter Author Contact No: ");
        String contactNo = in.nextLine();
        author.setContactNo(contactNo);
    }
    
   

}