public class Clerk  extends Protector
{
    String clerkId;
	
	
	
	public Clerk()
	{
		System.out.println(" " );
	}
	
	public Clerk (String clerkId)
	{
		this.clerkId=clerkId;
	}
	
	

    public void setClerkId(String clerkId)
	{
        this.clerkId=clerkId;
    }
    public String getClerkId()
	{
        return clerkId;
    }
    public void showInfo()
	{
        System.out.println("Library ID: "+id);
        System.out.println("Name: "+name);
        System.out.println("Joining Date : "+joiningDate);
        System.out.println("Email: "+email);
        System.out.println("Contact No: "+contactNo);
        System.out.println("Address: "+address);
        
    }
    
}