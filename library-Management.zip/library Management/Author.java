import java.util.Scanner;

public class Author
{
    int id;
    String name;
    String email;
	String contactNo;
	
	
	
	
	public Author ()
	{
		System.out.println("  " );
	}

    public Author (int id, String name, String email, String contactNo)
	{
	     this.id=id;
		 this.name=name;
		 this.email=email;
		 this.contactNo=contactNo;
	}
	
    public void setId(int id)
	{
        this.id=id;
    }
    public void setName(String name)
	{
        this.name=name;
    }   
    public void setEmail(String email)
	{
        this.email=email;
    }	
	public void setContactNo(String contactNo)
	{
        this.contactNo=contactNo;
    } 
    public int getId()
	{
        return id;
    }

    public String getName()
	{
        return name;
    }
     
    public String getEmail()
	{
        return email;
    }	
	public String getContactNo()
	{
        return contactNo;
    }
	 
	public  void  showInfo()
	{
		 System.out.println("Library ID: "+id);
		 System.out.println("Name: "+name);
		 System.out.println("Email: "+email);
		 System.out.println("Contact No: "+contactNo);
	}
	
	 
    
}