public abstract class Protector
{
    int id;
    String name;
    String departmentName;
	String joiningDate;
    String email;
    String contactNo;
    String address;
	
	
	public Protector()
	{
		System.out.println("  " );
	}
	
	public Protector(int id,String name,String departmentName,String joiningDate, String email, String contactNo,String address)
	{
		
		this.id=id;
		this.name=name;
		this.departmentName=departmentName;
		this.joiningDate=joiningDate;
		this.email=email;
		this.contactNo=contactNo;
		this.address=address;
	}
	
    

    public void setId(int id)
	{
        this.id=id;
    }
    public void setName(String name)
	{
        this.name=name;
    }
    public void setDepartmentName(String departmentName)
	{
        this.departmentName=departmentName;
    }
	public void setJoiningDate(String joiningDate)
	{
		this.joiningDate=joiningDate;
	}
	
    public void setEmail(String email)
	{
        this.email=email;  
    }
    public void setContactNo(String contactNo)
	{
        this.contactNo=contactNo;
    }
    public void setAddress(String address)
	{
        this.address=address;
    }   
    public int getId()
	{
        return id;
    }   
    public String getName()
	{
        return name;
    }
    public String getDepartmentName()
	{
        return departmentName;
    }
	public String getJoiningDate()
	{
		return joiningDate;
	}
	
    public String getEmail()
	{
        return email;
    }
    public String getContactNo()
	{
        return contactNo;
    }
    public String getAddress()
	{
        return address;
    }
   
    public abstract void showInfo();
}