import java.util.Scanner;

public class Start
{
    public static void main(String[] args)
	{
        Scanner in=new Scanner(System.in);
        StudentOperations studentoperations=new StudentOperations();
        Student student=new Student();

        ClerkOperations clerkoperations=new ClerkOperations();
        Clerk clerk=new Clerk();

        BookOperations bookoperations=new BookOperations();
        Book book=new Book();
		
		
        BasicOperations basicoperations=new BasicOperations();
        Protector protector ;

    
        int i=1;
        while(i!=-1)
		{
			System.out.println("  ********************");
			System.out.println("  ********************");
			System.out.println("  ********************\n");
			System.out.println("  Hello ...!! Good  Morning  " );
			System.out.println("\n WELCOME   TO   AIUB   LIBRARY..\n");
			System.out.println("  ********************");
			System.out.println("  ********************");
			System.out.println("  ********************\n");
			System.out.println("\n HOW CAN  I HELP  YOU.........\n");
            System.out.println("\n\t***LIBRARY MENU***\n");
			System.out.println("[1] Student Management\n[2] Clerk Management\n[3] Book Management\n[4] Basic Operations\n");
            System.out.println("\nEnter the choice:");
            int choice=in.nextInt();
           
            if(choice==1)
			{
                while(i!=-2)
				{
                    System.out.println("\n\t[1]Student Information\n");
					System.out.println("\n[1] Insert New Student\n[2] Search by studentId\n[3] Show All Student\n[4] Main Manu\n");
                    System.out.println("Enter the choice:");
                    int student_choice =in.nextInt();
                    if(student_choice==1)
					{
                        studentoperations.insertStudent(student);
                        continue;
                    }
                    else if(student_choice==2)
					{
                        System.out.println("Enter student ID:");
                        int id=in.nextInt();
                        studentoperations.getStudent(id);
                        continue;
                    }
                    else if(student_choice==3)
					{
                        studentoperations.showAllStudents();
                        continue;
                    }
                    else
					{
                        break;
                    }

                }
            }

            else if(choice==2)
			{
                while(i!=-2)
				{
                    System.out.println("\n\t\t[2]Clerk Information\n");
					System.out.println("[1] Insert New Clerk\n[2] Search by ClerkId\n[3] Show All Clerk\n[4] Main Manu");
                    System.out.println("\nEnter the choice:");
                    int clerk_choice =in.nextInt();
                    if(clerk_choice==1)
					{
                        clerkoperations.insertClerk(clerk);
                        continue;
                    }
                
                    else if(clerk_choice==2)
					{
                        System.out.println("Enter Clerk ID:");
                        int id=in.nextInt();
                        clerkoperations.getClerk(id);
                        continue;
                    }
                    else if(clerk_choice==3)
					{
                        clerkoperations.showAllClerks();
                        continue;
                    }
                    else
					{
                        break;
                    }
                
               }
                
           }
		   
           else if(choice==3)
		   {
            while(i!=-2)
			{
                System.out.println("\n\t\t[3]Book Information\n");
				System.out.println("[1] Insert New Book\n[2] Search by bookId\n[3] Show All Books\n[4] Main Manu");
                System.out.println("Enter the choice:");
                int teacher_choice =in.nextInt();
                if(teacher_choice==1)
				{
                    bookoperations.insertBook(book);
                    continue;
                }
            
                else if(teacher_choice==2)
				{
                    System.out.println("Enter Book ID:");
                    int id=in.nextInt();
                    bookoperations.getBook(id);
                    continue;
                }
                else if(teacher_choice==3)
				{
                    bookoperations.showAllBooks();
                    continue;
                }
                else
				{
                    break;
                }
            
		}
           }

           else if(choice==4)
		   {
            while(i!=-2)
			{
                System.out.println("\n\t\t[1] Borrow book\n\t\t[2] Return Book\n\t\t[3] Add Fine\n\t\t[4] Main Manu\n");
                System.out.println("\tEnter the choice:");
                int basic_choice =in.nextInt();

                if(basic_choice == 1)
				{
                    protector=student;
                    basicoperations.borrow(protector,book);
                    continue;
                }
            
                else if(basic_choice == 2)
				{
                    protector=clerk;
                    basicoperations.returnBook(protector,book);
                    continue;
                }
                else if(basic_choice==3)
				{
                    
                    protector=student;
                    System.out.println("\n1.For book lost = 450 taka\n2.For late return = 65 taka");
                    int fine_choice=in.nextInt();     
                        
                        
                        basicoperations. fine(protector);

                        continue;
                }
                else
				{
				
                    break;
                }
            
           }
           }

            else
			{
                
                break;
            }
            
        }
        
    }
}