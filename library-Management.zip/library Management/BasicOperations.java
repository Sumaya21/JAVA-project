import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;


interface IBasicOperations
{
    public void borrow(Protector p, Book b);
    public void returnBook(Protector p, Book b);
    public void fine(Protector p);
}

public class BasicOperations implements IBasicOperations 
{
	
	
    
    Scanner in=new Scanner(System.in);
   
	
    char choice;

    BookOperations bookOp;
    StudentOperations studentOp;
    

    public void borrow(Protector p, Book b)
	{
        System.out.println("Enter Book ID: ");
        int bookId= in.nextInt();
        System.out.println("1. Teacher : ");
		System.out.println("  < or >  ");
        System.out.println("2. Student: ");
        choice = in.next().charAt(0);
        if(choice == '1')
		{
            System.out.println("Enter Teacher ID:");
            int teacherId = in.nextInt();         
            System.out.println("Please collect book. Thank you!");
        }

        else
		{
            System.out.println("Enter Student ID:");
            int studentId = in.nextInt();
            System.out.println("Please collect book. Thank you!");   
        }
    }

    public void returnBook(Protector p, Book b)
	{
        System.out.println("Enter Book ID: ");
		int bookId= in.nextInt();
        System.out.println("1. Teacher : ");
		System.out.println("  < or >  ");
        System.out.println("2. Student: ");
        choice = in.next().charAt(0);
        if(choice == '1')
		{
            System.out.println("Enter Teacher ID:");
            choice = in.next().charAt(0);
            if(choice == 'Y')
			{
								
                System.out.println("Book has been returned.");
            }
            else
			{
                System.out.println("Book has not been returned.");
            }
        }

        else
		{
            System.out.println("Enter Student ID:");
            choice = in.next().charAt(0);
            if(choice == 'Y')
			{
                System.out.println("Book has been returned.");
            }
            else
			{
                System.out.println("Book has not been returned.");
            }  
        }
    }

    public void fine(Protector p)
	{
        System.out.println("1. Teacher : ");
		System.out.println("  < or >  ");
        System.out.println("2. Student: ");
		
        choice = in.next().charAt(0);
		System.out.println("Please pay your fine");
		
    }
    
}